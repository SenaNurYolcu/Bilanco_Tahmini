"""Resolve the data directory: env override -> repo-root real data -> loud synthetic fallback."""
from __future__ import annotations
import os
import pathlib

COMP_FILE = "comp_data.parquet"


def data_dir() -> pathlib.Path:
    """EPS_DATA_DIR if set, else <repo root>/data, independent of the current working directory."""
    env = os.environ.get("EPS_DATA_DIR")
    if env:
        return pathlib.Path(env)
    return pathlib.Path(__file__).resolve().parents[2] / "data"


def ensure_compustat(generate_if_missing: bool = True) -> pathlib.Path:
    """Return path to comp_data.parquet; synthesize into the data dir if absent.

    Prints exactly one provenance line so a run can never silently fall back to synthetic data.
    """
    d = data_dir()
    f = d / COMP_FILE
    if f.exists():
        print(f"[epsforecast] using REAL data from {f.name}")
        return f
    if not generate_if_missing:
        raise FileNotFoundError(f"{f} not found and synthetic generation disabled")
    print(f"[epsforecast] WARNING: {COMP_FILE} not found, generating SYNTHETIC data in {d.name}")
    from epsforecast.synthetic import write_synthetic
    write_synthetic(d, n_firms=800, n_quarters=80, seed=0)
    return f
