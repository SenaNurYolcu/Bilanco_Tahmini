import pandas as pd
from epsforecast.synthetic import make_compustat

REQUIRED = {"gvkey", "datadate", "fyearq", "fqtr", "sic", "epsfxq", "ibq", "oancfq",
            "atq", "actq", "lctq", "ltq", "saleq", "cogsq", "cshoq"}

def test_make_compustat_schema_and_panel():
    df = make_compustat(n_firms=50, n_quarters=40, seed=0)
    assert REQUIRED.issubset(df.columns)
    # SIC is fixed per firm and the panel contains a financial (6000-6999) block
    assert (df.groupby("gvkey")["sic"].nunique() == 1).all()
    fin_share = df["sic"].between(6000, 6999).mean()
    assert 0 < fin_share < 0.5
    # balanced-ish panel, sorted within firm by date
    g = df.sort_values(["gvkey", "datadate"]).groupby("gvkey")["datadate"]
    assert (g.apply(lambda s: s.is_monotonic_increasing)).all()
    # epsfxq is autocorrelated by construction (lag1 corr > 0.3)
    df = df.sort_values(["gvkey", "datadate"])
    df["lag1"] = df.groupby("gvkey")["epsfxq"].shift(1)
    assert df[["epsfxq", "lag1"]].dropna().corr().iloc[0, 1] > 0.3

def test_make_compustat_deterministic():
    a = make_compustat(n_firms=10, n_quarters=20, seed=42)
    b = make_compustat(n_firms=10, n_quarters=20, seed=42)
    pd.testing.assert_frame_equal(a, b)
