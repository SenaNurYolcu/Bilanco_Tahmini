import pathlib

import epsforecast.synthetic as synthetic
from epsforecast.config import data_dir, ensure_compustat

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]


def test_data_dir_env_override(tmp_path, monkeypatch):
    monkeypatch.setenv("EPS_DATA_DIR", str(tmp_path))
    assert data_dir() == tmp_path


def test_data_dir_is_repo_root_anchored_not_cwd(tmp_path, monkeypatch):
    # without the env var, data/ must resolve to the repo root regardless of the cwd
    monkeypatch.delenv("EPS_DATA_DIR", raising=False)
    monkeypatch.chdir(tmp_path)
    assert data_dir() == REPO_ROOT / "data"


def test_real_data_prints_exactly_one_real_line(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("EPS_DATA_DIR", str(tmp_path))
    f = tmp_path / "comp_data.parquet"
    f.write_bytes(b"")  # existence is all ensure_compustat checks
    got = ensure_compustat()
    out = capsys.readouterr().out
    assert got == f
    # file *name* only, so committed notebook outputs never embed absolute paths
    assert out == f"[epsforecast] using REAL data from {f.name}\n"


def test_synthetic_fallback_prints_exactly_one_warning_line(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("EPS_DATA_DIR", str(tmp_path))
    calls = []
    monkeypatch.setattr(synthetic, "write_synthetic",
                        lambda d, **kw: calls.append((d, kw)))
    ensure_compustat()
    out = capsys.readouterr().out
    assert out == (f"[epsforecast] WARNING: comp_data.parquet not found, "
                   f"generating SYNTHETIC data in {tmp_path.name}\n")
    assert len(calls) == 1  # the generator was actually invoked
