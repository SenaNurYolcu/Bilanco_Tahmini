import numpy as np
import pandas as pd
import pytest
from epsforecast.evaluate import (rmse, mae, time_split, seasonal_naive_rmse, oos_report,
                                  loss_differential_test)
from epsforecast.features import fit_winsor_bounds


class _ConstModel:
    """Stub with the predict() interface oos_report expects."""

    def __init__(self, value):
        self.value = value

    def predict(self, X):
        return np.full(len(X), self.value, dtype=float)


def test_rmse_basic():
    assert rmse(np.array([1.0, 2.0]), np.array([1.0, 4.0])) == np.sqrt((0 + 4) / 2)


def test_mae_basic_and_nan_safe():
    assert mae(np.array([1.0, 2.0]), np.array([1.0, 4.0])) == 1.0
    y = np.array([1.0, np.nan, 3.0])
    p = np.array([1.0, 99.0, 3.0])
    assert mae(y, p) == 0.0


def test_oos_report_evaluates_against_raw_target():
    # Winsor bounds fit on train must NOT be applied to the test target used in evaluation:
    # one extreme raw test EPS has to show up, at full size, in the reported RMSE.
    train = pd.DataFrame({"epsfxq": np.linspace(-1.0, 1.0, 101)})
    bounds = fit_winsor_bounds(train, ["epsfxq"])
    assert bounds["epsfxq"]["hi"] <= 1.0  # clipping would shrink the outlier to ~1

    test = pd.DataFrame({"epsfxq": [0.0, 1000.0], "epsfxq_lag4": [0.0, 0.0]})
    report = oos_report(test, _ConstModel(0.0), _ConstModel(0.0), ["epsfxq_lag4"],
                        y_true=test["epsfxq"])

    expected_raw_rmse = float(np.sqrt((0.0**2 + 1000.0**2) / 2))
    for model in ("OLS", "GBM", "seasonal_naive"):
        got = float(report.loc[report["model"] == model, "rmse_oos"].iloc[0])
        assert np.isclose(got, expected_raw_rmse)
        assert got > 100 * bounds["epsfxq"]["hi"]  # raw outlier, not the clipped value


def test_rmse_ignores_nan_targets():
    y = np.array([1.0, np.nan, 3.0])
    p = np.array([1.0, 99.0, 3.0])
    assert rmse(y, p) == 0.0


def test_time_split_is_chronological():
    df = pd.DataFrame({"datadate": pd.to_datetime(
        ["2001-03-31", "2005-03-31", "2009-03-31"])})
    train, test = time_split(df, cutoff="2007-01-01")
    assert train["datadate"].max() < pd.Timestamp("2007-01-01")
    assert test["datadate"].min() >= pd.Timestamp("2007-01-01")


def test_seasonal_naive_uses_lag4():
    # if epsfxq == epsfxq_lag4 exactly, seasonal-naive RMSE is 0
    df = pd.DataFrame({"epsfxq": [1.0, 2.0], "epsfxq_lag4": [1.0, 2.0]})
    assert seasonal_naive_rmse(df) == 0.0


def test_loss_differential_test_detects_better_model():
    # clearly better model A -> positive mean differential, significantly so, with many firms
    rng = np.random.default_rng(0)
    n_firms, n_obs = 200, 8
    n = n_firms * n_obs
    groups = np.repeat(np.arange(n_firms), n_obs)
    y = rng.normal(0.0, 1.0, n)
    pred_good = y + rng.normal(0.0, 0.1, n)
    pred_bad = y + rng.normal(0.0, 1.0, n)
    for loss in ("squared", "absolute"):
        mean_d, t = loss_differential_test(y, pred_good, pred_bad, groups, loss=loss)
        assert mean_d > 0
        assert t > 2
        # antisymmetric: swapping the pair flips both the mean and the t
        mean_r, t_r = loss_differential_test(y, pred_bad, pred_good, groups, loss=loss)
        assert np.isclose(mean_r, -mean_d)
        assert np.isclose(t_r, -t)


def test_loss_differential_test_nan_safe_and_validates_loss():
    y = np.array([0.0, np.nan, 1.0, 2.0])
    a = np.array([0.0, 0.0, 1.0, 2.0])  # perfect on valid rows
    b = np.array([1.0, 0.0, 2.0, 4.0])  # off by 1, 1, 2 on valid rows
    g = np.array([1, 1, 2, 2])
    mean_d, _ = loss_differential_test(y, a, b, g, loss="squared")
    assert np.isclose(mean_d, (1.0 + 1.0 + 4.0) / 3)
    with pytest.raises(ValueError):
        loss_differential_test(y, a, b, g, loss="huber")
