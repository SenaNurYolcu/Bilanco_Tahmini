"""Schema-faithful synthetic Compustat panel so the notebook runs without WRDS.

The numbers are fictitious but preserve the structure the model exploits:
firm fixed effects, EPS persistence (AR + seasonal), and plausible scaled ratios.
Each firm carries a fixed SIC code, including a financial 6000-6999 block, so the
notebook's sample-selection decomposition by sector runs on synthetic data too.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

FINANCIAL_SICS = [6022, 6311, 6726]                            # banks, insurers, funds
NONFINANCIAL_SICS = [2834, 2911, 3674, 3714, 5331, 7372]


def make_compustat(n_firms: int = 800, n_quarters: int = 80, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    start = pd.Timestamp("2000-03-31")
    dates = pd.date_range(start, periods=n_quarters, freq="QE")
    rows = []
    for i in range(n_firms):
        gvkey = 10000 + i
        # ~12% financial firms (SIC 6000-6999), fixed per firm like the real panel
        sic = int(rng.choice(FINANCIAL_SICS if rng.random() < 0.12 else NONFINANCIAL_SICS))
        assets = rng.lognormal(mean=6.0, sigma=1.0)            # ~ $400M median
        firm_eps = rng.normal(0.3, 0.4)                        # firm mean EPS
        seasonal = rng.normal(0, 0.15, size=4)                 # quarter-of-year effect
        eps_prev = firm_eps
        for t, dd in enumerate(dates):
            q = (t % 4) + 1
            # AR(1) + seasonal + shock; persistence ~0.6
            eps = 0.6 * eps_prev + 0.4 * firm_eps + seasonal[t % 4] + rng.normal(0, 0.20)
            eps_prev = eps
            sale = max(assets * rng.uniform(0.15, 0.45), 1.0)
            cogs = sale * rng.uniform(0.55, 0.85)
            ib = eps * rng.uniform(8, 30)                       # net income (millions)
            oancf = ib + rng.normal(0, abs(ib) * 0.5 + 1)       # cash flow ~ income + accrual noise
            rows.append({
                "gvkey": gvkey, "datadate": dd,
                "fyearq": dd.year, "fqtr": q,
                "sic": sic,
                "epsfxq": round(eps, 4),
                "ibq": round(ib, 4),
                "oancfq": round(oancf, 4),
                "atq": round(assets * rng.uniform(0.95, 1.05), 4),
                "actq": round(assets * rng.uniform(0.3, 0.6), 4),
                "lctq": round(assets * rng.uniform(0.1, 0.3), 4),
                "ltq": round(assets * rng.uniform(0.4, 0.7), 4),
                "saleq": round(sale, 4),
                "cogsq": round(cogs, 4),
                "cshoq": round(rng.uniform(5, 500), 4),
            })
    df = pd.DataFrame(rows).sort_values(["gvkey", "datadate"]).reset_index(drop=True)
    return df


def write_synthetic(data_dir, **kwargs) -> str:
    import pathlib
    p = pathlib.Path(data_dir)
    p.mkdir(parents=True, exist_ok=True)
    out = p / "comp_data.parquet"
    make_compustat(**kwargs).to_parquet(out, index=False)
    return str(out)
