"""Predictor construction. Every predictor is scaled and lagged >=1 quarter (no look-ahead).
Lags are validated against the fiscal calendar (fyearq, fqtr): a lag of n quarters is kept only
when the firm's fiscal-quarter index gap is exactly n, so a missing quarter yields a missing
lag, never a silently misaligned one.
Winsorization bounds are FIT on training only and APPLIED to all (fixes leakage)."""
from __future__ import annotations
import pandas as pd

PREDICTORS = ["epsfxq_lag1", "epsfxq_lag4", "cfo_lag1", "accruals_lag1",
              "gross_margin_lag1", "asset_turnover_lag1", "sales_growth_lag1", "lev_lag1"]


def build_predictors(comp: pd.DataFrame) -> pd.DataFrame:
    df = comp.sort_values(["gvkey", "datadate"]).reset_index(drop=True)
    roa = (df["ibq"] / df["atq"]).where(df["atq"] > 0)
    df["cfo"] = (df["oancfq"] / df["atq"]).where(df["atq"] > 0)
    df["accruals"] = roa - df["cfo"]
    df["gross_margin"] = ((df["saleq"] - df["cogsq"]) / df["saleq"]).where(df["saleq"] > 0)
    df["asset_turnover"] = (df["saleq"] / df["atq"]).where(df["atq"] > 0)
    df["lev"] = ((df["ltq"] - df["lctq"]) / df["atq"]).where(df["atq"] > 0)
    # fiscal-contiguity guard: positional shift(n) within firm is only a valid n-quarter lag
    # when the fiscal-quarter index moved by exactly n (missing quarter -> missing lag)
    fiscal_idx = df["fyearq"] * 4 + df["fqtr"]
    contig1 = (fiscal_idx - fiscal_idx.groupby(df["gvkey"]).shift(1)) == 1
    contig4 = (fiscal_idx - fiscal_idx.groupby(df["gvkey"]).shift(4)) == 4
    df["saleq_l4"] = df.groupby("gvkey")["saleq"].shift(4).where(contig4)
    df["sales_growth"] = (df["saleq"] / df["saleq_l4"] - 1).where(df["saleq_l4"] > 0)
    for v in ["epsfxq", "cfo", "accruals", "gross_margin", "asset_turnover", "sales_growth", "lev"]:
        df[f"{v}_lag1"] = df.groupby("gvkey")[v].shift(1).where(contig1)
    df["epsfxq_lag4"] = df.groupby("gvkey")["epsfxq"].shift(4).where(contig4)
    return df


def fit_winsor_bounds(train: pd.DataFrame, cols, lo_q=0.01, hi_q=0.99) -> dict:
    return {c: {"lo": train[c].quantile(lo_q), "hi": train[c].quantile(hi_q)} for c in cols}


def apply_winsor(df: pd.DataFrame, bounds: dict) -> pd.DataFrame:
    out = df.copy()
    for c, b in bounds.items():
        out[c] = out[c].clip(lower=b["lo"], upper=b["hi"])
    return out
