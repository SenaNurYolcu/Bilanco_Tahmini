"""Load Compustat quarterly data (real or synthetic) with the columns the model needs."""
from __future__ import annotations
import pandas as pd
from epsforecast.config import ensure_compustat

COLS = ["gvkey", "datadate", "fyearq", "fqtr", "sic", "epsfxq", "ibq", "oancfq",
        "atq", "lctq", "ltq", "saleq", "cogsq"]


def load_compustat() -> pd.DataFrame:
    path = ensure_compustat()
    # the real file has the full fundq column set; synthetic mirrors the raw schema.
    # Read the intersection, only the columns the pipeline uses.
    available = pd.read_parquet(path, columns=None).columns
    use = [c for c in COLS if c in available]
    df = pd.read_parquet(path, columns=use)
    df["datadate"] = pd.to_datetime(df["datadate"])
    return df.sort_values(["gvkey", "datadate"]).reset_index(drop=True)
