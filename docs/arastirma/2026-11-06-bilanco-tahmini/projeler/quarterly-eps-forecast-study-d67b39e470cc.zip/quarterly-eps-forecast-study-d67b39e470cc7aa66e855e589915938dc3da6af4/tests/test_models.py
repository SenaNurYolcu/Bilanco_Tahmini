import numpy as np
from epsforecast.features import build_predictors, PREDICTORS
from epsforecast.models import fit_gbm
from epsforecast.synthetic import make_compustat


def test_fit_gbm_accepts_predictor_subset():
    panel = build_predictors(make_compustat(n_firms=30, n_quarters=12, seed=2))
    panel = panel.dropna(subset=PREDICTORS + ["epsfxq"])
    lag_cols = ["epsfxq_lag1", "epsfxq_lag4"]
    m = fit_gbm(panel, predictors=lag_cols)
    preds = m.predict(panel[lag_cols].to_numpy())
    assert preds.shape == (len(panel),)
    assert np.isfinite(preds).all()
