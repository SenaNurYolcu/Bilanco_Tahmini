"""OLS (firm-clustered SEs) baseline + gradient-boosted trees challenger."""
from __future__ import annotations
import statsmodels.formula.api as smf
from sklearn.ensemble import HistGradientBoostingRegressor
from epsforecast.features import PREDICTORS

FORMULA = "epsfxq ~ " + " + ".join(PREDICTORS)


def fit_ols(fit_panel):
    """OLS with cluster-robust SEs by firm (gvkey) for panel inference."""
    return smf.ols(FORMULA, data=fit_panel).fit(
        cov_type="cluster", cov_kwds={"groups": fit_panel["gvkey"]}
    )


def fit_gbm(fit_panel, random_state=0, predictors=None):
    """Gradient-boosted trees on `predictors` (default: the full PREDICTORS set)."""
    cols = PREDICTORS if predictors is None else list(predictors)
    X = fit_panel[cols].to_numpy()
    y = fit_panel["epsfxq"].to_numpy()
    model = HistGradientBoostingRegressor(
        max_depth=3, learning_rate=0.05, max_iter=400,
        l2_regularization=1.0, random_state=random_state,
    )
    model.fit(X, y)
    return model
