# ProForma-20Q

**A public benchmark for joint probabilistic forecasting of complete quarterly
financial statements at horizons 1–20 quarters.**

ProForma-20Q defines a *task*, not a model. Given your own WRDS credentials, one
command rebuilds the exact data environment and evaluation used in the companion
ICAIF '26 paper; you then train *your* model and score a forecast file with our
CLI. It is usable by someone who has never heard of the Forma model — build the
data, train, submit.

> **No Compustat-derived data is distributed here.** This repository is
> Apache-2.0 and holds code, configs and file digests only. Every
> Compustat-*derived* artifact — the canonical regularization statistics, the
> Full-sample coverage bitmap and its row index, the canonical per-column drift
> statistics, and the released forecasts — is published separately under the
> Forma Non-Commercial Research Licence from gated Hugging Face repositories,
> and fetched on demand. The gates are automatic. See
> [Code and data are licensed separately](#code-and-data-are-licensed-separately).
> WRDS / Compustat / CRSP credentials and license are entirely the user's
> responsibility.

---

## What it is

- **Universe.** Compustat Fundamentals Quarterly (`comp.fundq`) via WRDS,
  1970–2024, financial firms (SIC 6000–6999) excluded.
- **Targets.** The **78 `pf_full` statement items** — the full income statement,
  balance sheet, and cash-flow statement — forecast **jointly** at horizons
  **h = 1..20** quarters. No firm identifiers are used as features
  (universal-forecaster rule).
- **Splits (by calendar time).** train 1971–2001 / val 2002–2009 / test 2010–2024.
- **Transform.** Every item is scaled by a firm-size proxy, passed through
  `asinh`, z-scored per item, and clamped to `|z| ≤ 6`. All forecasting and
  scoring happen in this regularized space. (The transform is `asinh`, *not*
  signed-log — some legacy docs are wrong.)
- **Two data views.** A **tabular** lagged feature matrix (4 recent levels + 8
  YoY changes per item, plus FF48 industry dummies) and a **tuple**
  `(account, quarter, value)` sparse form. Both builders ship.
- **Evaluation.** Change-space R² (shared denominator), MAE/MSE, and — for
  forecasts that carry a `sigma` — NLL, CRPS, and calibration (z2, cover95), on a
  strict all-models common sample. See [SUBMISSION.md](SUBMISSION.md).

---

## Install

Install from source — the supported path today (any modern Python 3.10+):

```bash
# from the ROOT of a download or clone of this repository -- note the review
# mirror's zip extracts its contents directly, without a wrapper directory:
pip install -e '.[wrds,dev]'        # scoring + baselines + WRDS client + tests
```

(The quotes matter under zsh, macOS's default shell, which otherwise globs the
brackets.) Use `pip install -e '.[wrds]'` if you only need the data build, or
`pip install -e .` for the scoring/baseline path alone (no WRDS client).

> **PyPI — available once published.** On release the package will also install
> straight from PyPI. This is **not yet available** (publication happens when the
> repository goes public at submission):
>
> ```bash
> pip install proforma-20q          # scoring + baselines
> pip install proforma-20q[wrds]    # also the WRDS client, for the data build
> ```

---

## Before you start: data access and preconditions

ProForma-20Q is a **protocol, not a dataset**. Every artifact is rebuilt from
your own Compustat licence, so the benchmark cannot be run at all without the
access below.

| source | used for | required? |
|---|---|---|
| WRDS account | all data access, via the [`wrds`](https://pypi.org/project/wrds/) client | **yes** |
| Compustat Fundamentals Quarterly (`comp.fundq`) | the 78 statement items | **yes** |
| Compustat `comp.co_industry` | SIC/NAICS → FF48 industry dummies, and the financial-sector exclusion | **yes** |
| CRSP `crsp.ccmxpf_lnkhist` (CCM link table) | **part of the sample definition** — trims linked firms to their link windows; see [The CRSP link filter](#the-crsp-link-filter) | **yes** |

> **CRSP is not optional.** The link merge trims *linked* firms to their link
> windows, which is part of the published sample definition (firms with no CCM
> link are retained in full — see [The CRSP link filter](#the-crsp-link-filter)).
> Skipping it yields a larger, systematically different universe whose scores
> are **not comparable** to the leaderboard.

### Step 0 — authenticate to WRDS

Do this first, and verify it, before running anything else.

**1. Install the client:** `pip install -e '.[wrds]'`

**2. Create a `pgpass` file** so the build is non-interactive. The path is
platform-specific — the POSIX one is not the only one:

| platform | path |
|---|---|
| Linux / macOS | `~/.pgpass` (must be `chmod 600`) |
| **Windows** | `%APPDATA%\postgresql\pgpass.conf` |

One line, five colon-delimited fields:

```
wrds-pgdata.wharton.upenn.edu:9737:wrds:<your_wrds_username>:<your_wrds_password>
```

**3. ⚠ Expect Duo two-factor — even with a valid `pgpass` file.** A `pgpass`
supplies your *password*; it does not satisfy WRDS's second factor. Connecting
may send a **Duo push to your phone that you must approve**.

> **Do not retry a failed connection in a loop.** Repeated authentication
> attempts without a Duo response cause **WRDS to deactivate the account**, which
> takes a support ticket to undo. If a connection fails, stop and fix the cause.
>
> Duo may *not* prompt on every connection — device-trust windows mean an
> authentication can succeed silently now and require a push later, from a new
> machine or IP. **One silent success does not mean 2FA is not enforced.**

`proforma20q download` makes exactly one connection attempt per run and never
retries. If you are driving this repo programmatically, read
[AGENTS.md](AGENTS.md) first.

**4. Verify once:**

```bash
python -c "import wrds; db = wrds.Connection(wrds_username='<user>'); print(db.raw_sql('select count(*) from comp.fundq limit 1')); db.close()"
```

### What you can do *without* credentials

Works with **no credentials and no network**: `pip install -e '.[dev]'` and the
full test suite (all synthetic, no WRDS); `proforma20q validate <file>`;
`proforma20q evaluate <file> --truth examples/example_truth.parquet`; reading
`task.yaml` / `feature_sets.yaml`.

Needs a **Hugging Face account** (free, auto-accepted gate — see [Code and data
are licensed separately](#code-and-data-are-licensed-separately)) but no WRDS:
downloading the released forecasts, the Full-sample mask and its row index, and
therefore `evaluate --sample-mask`.

Requires **WRDS credentials**, no workaround: `proforma20q build` and therefore
every real artifact, any leaderboard number, and `report-drift`.

---

## Quickstart

### 1. Build the data (needs WRDS)

```bash
proforma20q build --wrds-user <your_wrds_user>
# -> authenticates ONCE (see Step 0; expect a Duo push)
# -> downloads Compustat+CRSP, processes both views, verifies checksums
proforma20q report-drift
# -> the PASS/FAIL vintage-drift verdict (see "Reproducing the canonical build")
```

The build ends with a **bit-exact md5 verification**, and on any fresh WRDS
pull it will print `mismatch` for every artifact and `ALL MATCH: False`. That
is expected — Compustat is revised, so bit-exact equality with the canonical
snapshot is not achievable ([details](#reproducing-the-canonical-build)). The
check with a real verdict is the second command: `report-drift` compares
per-column distribution statistics against the published canonical ones and
returns PASS/FAIL. (`build --report-drift` runs it in one step.)

This writes the tabular and tuple artifacts to `data/processed/`. The
**tabular test file is also the evaluation ground truth** — there is no separate
truth file.

If you already have the raw panel, skip the download:

```bash
proforma20q build --raw data/raw/compustat_with_permno.parquet
```

**What it costs.** Measured on the canonical 1970–2024 panel (1,531,703 × 655),
`--which tabular --reg-stats canonical`, on a 34 GB Windows workstation:

| stage | peak RSS | wall |
|---|---|---|
| raw load + prep (YTD → computed items → scale) | 4.5 GB | ~20 s |
| wide-matrix build (1,173,598 × 2,547) | 13.7 GB | ~3 min |
| writing the three splits (~6.7 GB of parquet) | 20.3 GB | ~12 min |

The download pulls **82 of `comp.fundq`'s 648 columns** — the ones the benchmark
consumes — and does it in one-year chunks by default, cached under
`data/raw_chunks/` so an interrupted pull resumes. `--chunk-years 0` issues a
single query instead; `--all-columns` restores the old `SELECT f.*` (~7.9× more
data, ~100 GB peak over 1970–2024 — it does not complete on an ordinary
machine). `build --raw` applies the same projection when reading the panel, so
an existing `SELECT f.*` parquet costs no more than a projected one.

### Which reg stats: the flag that changes your ground truth

`--reg-stats` selects the statistics that define the **regularized target
space**, i.e. the ground truth you are scored against. It is not a tuning knob:

| value | meaning |
|---|---|
| `canonical` **(default)** | pin the published R13 statistics shipped in `src/proforma20q/reference/`. Your targets are the leaderboard's targets. |
| `estimate` | re-estimate `mu`/`sigma`/`k` from *your* panel's train split. A different ground truth — scores are **not comparable** to anything published. |
| *a path* | pin an explicit `regularization_stats__*.parquet`. |

Building twice from an identical panel and toggling only this flag gave **0.0%
of target cells identical** and a mean |Δz| of 0.83 in a space clamped to
|z| ≤ 6, plus a 6-row change in the train split. (That magnitude was measured on
a synthetic panel whose scale distribution is unlike Compustat, so 0.83
overstates the real gap — the mechanism and the row-count change are real
regardless.) Two researchers both "following the README" would otherwise score
against different truth and produce non-comparable numbers, which is why the
default is pinned and the build prints which space it used.

### The CRSP link filter

`download` merges the CRSP-Compustat link table (`crsp.ccmxpf_lnkhist`,
`linktype ∈ {LU, LC}`, `linkprim ∈ {P, C}`). **This is part of the sample
definition**, declared in
[`task.yaml → universe.crsp_link`](src/proforma20q/configs/task.yaml), and its
outcome is a clean two-regime split:

- **Firms with a CCM link are trimmed to their link windows** — firm-quarters
  whose `datadate` falls outside every valid window are dropped.
- **Firms with no CCM link at all are retained in full**, with NaN `permno`.
  This is not a corner case: on the canonical 1970–2024 pull, 16,418 of 43,335
  firms — **495,440 firm-quarters, 29.0% of the panel** — have no link, a share
  that grows from 3.8% in the 1970s to **50.0% in the 2020s**. They are largely
  Canadian-incorporated filers plus smaller US firms (median `atq` 57.4 vs
  259.3 for linked). Carried into the shipped R13 splits: 12.5% of train,
  30.3% of val, and **34.4% of test** firm-quarters are unlinked.

A CRSP-listed universe is therefore **not** what this filter produces. What
CRSP entitlement buys you is the ability to reproduce the *trimming of linked
firms* exactly; membership itself never requires a CRSP listing. Skipping the
merge still yields a different, larger universe than the published one (the
out-of-window quarters of linked firms come back), so it is not optional
either.

The column it attaches, `permno`, is **never read downstream**. The window
trim is the point, and it is kept for comparability with the published sample.
(The output file is named `compustat_with_permno.parquet` after the column that
does not matter rather than the filter that does; the name is retained for
compatibility with existing pipelines.)

### If you train on the tuple view: the id maps

The tuple view stores `firm_id`, `account_id` and `industry_id` as **integers**,
while a submission needs the gvkey string (`"001045"`) and the pf_full item name
(`"niq"`). A build therefore also writes the three dictionaries that bridge them,
next to the artifacts:

```
firm_id_map__<suffix>.csv        account_id_map__<suffix>.csv
industry_id_map__<suffix>.csv
```

Read them with `proforma20q.build.read_id_maps(processed_dir, suffix)` rather
than a bare `read_csv`: `firm_id` is a **zero-padded** gvkey, and CSV has no
types, so a default read turns `"001045"` into the integer `1045` — which then
matches nothing in the truth file, silently.

**The account map has 79 entries, not 78.** The tuple view carries the size
deflator `scale` as an account (id **60**, between `revtq` = 59 and
`seqq` = 61) so a tuple-trained model can denormalize; the 18 items sorting
after `"scale"` therefore sit one id higher than a bare-78-item enumeration
would put them. Submissions still use only the 78 pf_full item *names* —
`scale` is never a forecast target.

These files also pin the ordering rule (ids are assigned by `sorted()`), which
matters because account and industry ids are embedding indices: a build whose
ordering differs from the one a checkpoint was trained under permutes its
embeddings without any error. **The canonical account and industry maps
therefore ship in this repository** —
[`src/proforma20q/reference/account_id_map__<suffix>.csv`](src/proforma20q/reference)
(79 rows) and `industry_id_map__<suffix>.csv` (49 rows). Both are derived
entirely from the in-repo task config and FF48 table (no WRDS data), so they
are exact for every vintage, and `report-drift` checks a build's maps against
them (any difference is a FAIL: it is precisely the silent-permutation risk
these files exist to prevent). The **firm map is deliberately not pinned**: its
gvkey universe drifts with the Compustat vintage (canonical: 41,595 firms; a
7-week-newer pull measured 41,601), so `report-drift` instead checks the
ordering rule (ids `0..n-1` by sorted gvkey) and that the firm count is within
1% of canonical — and firm ids must always be translated through the gvkey
strings, never assumed positionally comparable across builds.

### A third of the sample has no industry

FF48 comes from each firm's modal `sich`. On the canonical build **18,648 of
41,595 firms (44.8%)** map to `unknown`, so **494,970 rows (32.3%)** carry
all-zero `indff48_*` dummies. That is defensible — `unknown` is the dropped
reference level, so those rows sit at the intercept — but the industry block is
identically zero for a third of the data, which is worth knowing before you
build a model around it. Relatedly, the financial-sector exclusion keeps rows
with a *missing* `sich` (`missing != financial`), so ~7.8% of the final sample is
financial by NAICS. Both behaviours match the upstream research pipeline and are
documented in `task.yaml`.

### 2. Reproduce the reference baselines

Do this before trusting your own model's score — it is how you find out whether
your build reproduces the published numbers. **Run the two cheap ones first**;
the linear family takes the better part of a day (see
[Reference baselines](#reference-baselines)).

```bash
proforma20q baselines --which naive,fade      # ~15 min, ~8.5 GB peak
proforma20q evaluate --against baselines --out results/metrics
```

```bash
proforma20q baselines                          # adds elasticnet + linear: hours
```

### 3. Score your model

Produce a forecast file in the [submission format](SUBMISSION.md), then:

```bash
proforma20q validate my_forecasts.parquet
proforma20q evaluate my_forecasts.parquet --against baselines --out results/metrics
```

### Library API

```python
from proforma20q.build import build
from proforma20q.baselines import run_baselines
from proforma20q.evaluate import evaluate_forecasts
from proforma20q.baselines.common import load_tabular

truth = load_tabular("data/processed/tabular_test__pf_full__r13_node_optionD_indfe_val8.parquet")
result = evaluate_forecasts({"mine": "my_forecasts.parquet"}, truth)
print(result.leaderboard("r2"))
```

---

## Reference baselines

They anchor the leaderboard and let you verify your pipeline.

| baseline     | what it is | cost at canonical scale |
|--------------|------------|-------------------------|
| `naive`      | **seasonal random walk** — forecast for horizon *h* is the newest lagged level a whole number of years before the forecast quarter (`level_{(4−h mod 4) mod 4}`: h=1 ← `level_3`, h=2 ← `level_2`, h=3 ← `level_1`, h=4 ← `level_0`, repeating). Same-fiscal-quarter alignment; the paper's baseline anchor. Every model worth shipping beats it. | measured with the current specs (2026-08 vintage, 32 GB machine): naive+fade together **14.5 min / 8.4 GB peak**, writing two full-coverage ~550M-row forecasts (~2.7 GB each) |
| `fade`       | AR(1) / fade-to-mean — one `(ρ_{i,h}, b_{i,h})` per **(item, horizon)** pair (1,560 closed-form OLS fits on train+val), so each item fades toward its mean at its own speed. | ″ |
| `elasticnet` | per-horizon `(alpha, l1_ratio)` cross-validated on `niq` over 2002–2009 and reused across all 78 targets; refits on train+val. | **hours.** Measured one refit at canonical train size (578,831 × 985): 5.3 s at h=1, 1.8 s at h=20 → ~1–2 h for the 1,560 refits, plus ~1 h for the 840-fit CV grid (42 combos × 20 horizons) |
| `linear`     | plain OLS per (target, horizon). | **the most expensive of the four, not the cheapest.** Measured one fit at canonical train size: 32.5 s at h=1, 15.2 s at h=20 → **7–14 h** for 1,560 fits. OLS solves by SVD; coordinate descent with an L1 penalty is ~6× faster here |

Both linear-family baselines peaked at ~10 GB RSS in that measurement. For a
quick end-to-end pipeline check, run just the fast two:

```bash
proforma20q baselines --which naive,fade
```

**The Forma model is not included** — it is released separately.

## Leaderboard

The headline benchmark number is the **Full-sample pooled R²** — the paper's
327,244,429-cell column (see [Reproducing the paper's pooled tables](#reproducing-the-papers-pooled-tables)).
On a canonical build the shipped baselines score:

| model | R² (Full sample) |
|-------|:----------------:|
| naive (seasonal RW anchor) | −0.0412 |
| fade / AR(1) | 0.1827 |
| ElasticNet | 0.2585 |
| *your model here* | |

These are the same canonical values reproduced in the pooled table below;
regenerate them with a canonical build + `proforma20q evaluate --against baselines
--sample-mask …`. To add a model, open a PR with your forecast-file checksum and
reproduction instructions.

---

## Reproducing the canonical build

Compustat is **revised over time**, so a fresh WRDS pull today will not be
bit-identical to the canonical snapshot.

> **Bit-for-bit md5 equality with `checksums.json` is not achievable, and is not
> the target.** Three independent reasons, none removable by pinning
> dependencies: the canonical artifacts were written by a *different
> implementation* (the internal research repo) that agrees with this one to
> float32 epsilon rather than exactly; that implementation emits rows in a
> different order — `(year, firm, quarter)` vs `(firm, quarter)` here — and both
> file md5s and per-column hashes are position-sensitive; and Compustat is
> revised. Earlier releases presented md5 equality as the primary check. It never
> could have passed. **The supported check is the drift report below.**

1. **Pin the environment.** For a rebuild against pinned dependencies:
   ```bash
   pip install -r requirements-lock.txt
   ```
   It pins the **direct** dependencies (no hashes; transitive deps float), so two
   people on the same Compustat vintage get the same numbers. It is *not* the
   environment that produced the canonical artifacts — see the file's own header.
2. **Pin the query.** The exact WRDS SQL lives in `src/proforma20q/download.py`;
   the sample window and filters are in `src/proforma20q/configs/task.yaml`.
3. **Pin the target space.** Build with `--reg-stats canonical` so your targets
   are normalized against the published R13 statistics rather than re-estimated
   from your own vintage — see [Which reg-stats?](#which-reg-stats-the-flag-that-changes-your-ground-truth).
   The statistics are gated; the build fetches and md5-verifies them on first
   use, and **fails rather than silently re-estimating** — a re-estimated target
   space shares ~0% of its target cells with the published one.
4. **Publish statistics, not data.** `src/proforma20q/checksums.json` holds file
   md5s plus, per tabular artifact, the row/column counts — all Apache-2.0,
   since a hash is not the hashed content. The **per-column distribution
   summary** (coverage, mean, sd, p05/p50/p95 of the regularized values) is what
   makes drift *comparable* where a hash cannot be, but it is Compustat-derived,
   so it ships from the [gated dataset repo](#code-and-data-are-licensed-separately)
   as `checksums/canonical_column_stats.json` and `report-drift` fetches it.
   Provenance: the md5 pins are the canonical build's own; the distribution
   summary was computed from the canonical R13 research artifacts — the
   *internal* builder's output off the same panel, row-count-identical to the
   pins and measured to agree with this package's builder at worst |Δmean| 1e-06
   (see the calibration below). The statistics are order-invariant, so the two
   builders' differing row order cannot affect them; the exact recipe is
   `scripts/merge_canonical_column_stats.py` and the file records its own
   provenance in `_column_stats_source`, which `report-drift` echoes.
5. **Check drift, with a verdict.**
   ```bash
   proforma20q report-drift                       # vs the published statistics
   proforma20q report-drift --reference <dir>     # vs a build you already trust
   ```
   For each artifact it reports the row-count delta and the worst per-column
   move in mean, sd and coverage, then returns **PASS/FAIL** against documented
   thresholds and **exits non-zero on FAIL**.

   > If the canonical statistics cannot be fetched, the verdict is **NOT
   > VERIFIED** and the command **exits non-zero**. It never degrades to a pass
   > or a quietly skipped step: the promise is *verified by published
   > checksums*, so an unreachable reference means unverified, and a check the
   > user believes ran but did not is worse than no check. `--reference <dir>`
   > computes its statistics locally and needs no gate.

   It also checks the build's
   [id maps](#if-you-train-on-the-tuple-view-the-id-maps) against the pinned
   canonical reference: account/industry orderings must match exactly
   (embedding permutation is a FAIL); the firm map is checked for the ordering
   rule and a bounded count delta.

   | threshold | value |
   |---|---|
   | split row count, relative | ≤ 1% |
   | per column, \|Δ mean\| (z units) | ≤ 0.05 |
   | per column, \|Δ sd\| (z units) | ≤ 0.05 |
   | per column, \|Δ coverage\| (fraction finite) | ≤ 0.02 |

   Calibration, measured: the same task built by this package versus the internal
   builder off the same panel gives **0 of 2,497 columns out of tolerance**
   (worst \|Δ mean\| 1e-06, row delta 0); a build off a *synthetic* panel gives
   **290–317 of 321 columns out of tolerance** (worst \|Δ mean\| 1.39, rows −99%).
   The thresholds sit between those by five orders of magnitude. A genuine
   7-week vintage difference moved split row counts by 0.01% / 0.07% / 0.24%,
   comfortably inside the 1% row bound.

   > The **previous** metric — the fraction of per-column *hashes* that differ —
   > read **100.0% for both** of those cases, because one changed cell in 1.17M
   > flips a whole column's hash. It is retained only for an old
   > `checksums.json`, is labelled as not a drift measure, and never decides
   > pass/fail.

**Definition of done for a reproduction:** a fresh machine + WRDS login →
`build --reg-stats canonical` completes → `report-drift` returns **PASS** (exit
0) → `evaluate` on the shipped baseline forecasts reproduces the published
naive / fade / ElasticNet numbers on the Full-sample mask.

---

## Reproducing the paper's pooled tables

`evaluate` scores on the **all-submitted-models common sample** (a cell counts
only if every model you pass predicts it finitely). The paper's headline table
instead scores each column on a **fixed pooled sample** — the common sample of a
specific set of models, so that adding a new entrant never moves a published
number. Its primary column is the **Full sample: 327,244,429 cells**.

`--sample-mask` reproduces that. Pass a mask of the pooled cells and every metric
is computed on `mask ∩ your models' common sample`:

```bash
proforma20q evaluate my_forecasts.parquet --against baselines \
    --sample-mask data/artifacts/full_sample_mask_bits.npy
```

The mask comes in two interchangeable forms, and **which one you need depends on
your vintage**:

| form | matches by | survives vintage drift? |
|---|---|---|
| grid-aligned bit array (`.npy`, `np.packbits` of the canonical cell order — no firm identifiers) | **position** | **not alone** — it is a bitmap over an exact 352,962-row set; pair it with the canonical row index below |
| bit array **+ `--grid-rows`** (the published row index) | **value** | **yes** — the bitmap is realigned onto your grid by `(firm, origin)` |
| keys table (`firm, target, origin, horizon`) | **value** | **yes** — but building it needs the canonical `tabular_test`, which is not published |

**The prebuilt grid-aligned mask comes from the gated dataset repository**
([`full_sample_mask_bits.npy`](#data--artifacts), 66 MB; md5 `a36008d8…`, pinned
in [`scripts/full_sample_mask.manifest.json`](scripts/full_sample_mask.manifest.json)).
It is Compustat-derived, so it is not bundled in this Apache-2.0 tree — fetch it
and the row index once, into the directory the commands here use:

```bash
python scripts/download_artifacts.py --out data/artifacts \
    --only full_sample_mask_bits.npy full_sample_grid_rows.parquet
```

That is everything the command above needs — *if* your `tabular_test` is
row-identical to the canonical one. It will not be: Compustat is revised, so a
fresh pull drifts. **Pass the canonical row index alongside it and the
bitmap works anyway** — the index came down with the same command
([`data/artifacts/full_sample_grid_rows.parquet`](#data--artifacts), 1.9 MB):

```bash
proforma20q evaluate my_forecasts.parquet --against baselines \
    --sample-mask data/artifacts/full_sample_mask_bits.npy \
    --grid-rows data/artifacts/full_sample_grid_rows.parquet
```

`--grid-rows` names which `(firm, origin)` row each bit belongs to, so `evaluate`
translates the mask onto *your* grid by value and scores the paper's cells minus
the rows your vintage lacks — reporting exactly how many that is. **This is the
route that keeps "score me on Forma's cells" a 67 MB proposition rather than a
3.7 GB one**: you never need the Forma forecast to define the sample.

The index cannot be derived from the published forecast, which is why it is
published alongside the mask:
23,970 canonical rows (6.8%) carry no forecast at all — they contribute no mask
cells, yet still occupy grid positions the bitmap counts through.

> **Measured, on the canonical mask against a real WRDS rebuild** (a later
> vintage: 1,330 canonical rows gone, 474 new ones, net −856 = 0.24% drift):
> **326,401,062 of the 327,244,429 canonical cells realign — 99.74%.** Scoring
> the canonical Forma forecast through this route lands on 326,279,721 cells and
> gives R² **0.289232** / MAE **0.408311**, against **0.289172** / **0.408494**
> on the canonical build itself. Sixth-decimal moves — well inside the precision
> the paper reports, and far smaller than the ~5% sample difference you would
> incur by dropping the mask and scoring on your own model's coverage instead.

The keys form remains available and needs only the bit array plus the canonical
`tabular_test` — but that artifact is never published, so `--grid-rows` is the
supported route for outside users. `evaluate` names it in the error message if
you hand it a bit array that does not fit your grid. Because the reference
model's coverage is the binding constraint, the Full mask is exactly *its
finite-prediction cells ∩ truth*; `scripts/build_full_sample_mask.py` also
rebuilds and verifies it (`--expect 327244429`) offline from the Forma forecast,
reproducing the same md5.

Restricted to the Full mask, the shipped baselines reproduce the paper's Panel A
Full column **to the digit** (all on the identical 327,244,429-cell sample):

| baseline | R² (this repo) | R² (paper) |
|---|:--:|:--:|
| naive | −0.0412 | −0.041 |
| fade / AR(1) | 0.1827 | 0.183 |
| ElasticNet | 0.2585 | 0.258 |

**Sub-sample analysis.** The same flag scores any narrower pool — e.g. a mask
intersected with a model that only covers 25 targets (the paper's GBM column,
109 M cells) or a fixed-budget origin subsample (the LLM column, 2.15 M cells).
Those masks are *not* part of standard scoring; they are examples of the
sub-sample analyses the package enables for entrants with structural or budgetary
coverage limits.

---

## Code and data are licensed separately

**Code: Apache-2.0.** Everything in this repository — the package, the scripts,
the configs, the FF48 SIC ranges, the synthetic fixtures in `examples/`, and
the md5 file digests in `src/proforma20q/checksums.json` — is Apache-2.0 and
carries no usage restriction. A hash of a file is not that file's content.

**Data: Forma Non-Commercial Research Licence.** Compustat
reaches us through a WRDS licence that is non-commercial, and the underlying
rights are the University's. Apache-2.0 grants commercial use, so
Compustat-derived material cannot ship under it. Those artifacts are published
from gated Hugging Face repositories instead and fetched on demand:

| artifact | where | fetched by |
|---|---|---|
| `reference/regularization_stats.parquet` — per-`(feature, quarter)` `mu`/`sigma`/`k`, the target space | [`forma-lab-mccombs/forma`](https://huggingface.co/forma-lab-mccombs/forma) (model) | `build --reg-stats canonical` |
| `checksums/canonical_column_stats.json` — per-column coverage/mean/sd/p05/p50/p95 | [`forma-lab-mccombs/proforma-20q-artifacts`](https://huggingface.co/datasets/forma-lab-mccombs/proforma-20q-artifacts) (dataset) | `report-drift` |
| the coverage bitmap, its row index, and the released forecasts | same dataset repo | `scripts/download_artifacts.py` |

The regularization statistics sit with the model weights, not with the bundle,
so the `(mu, sigma, k)` defining the target space have a single source of truth
shared with the trained models.

The two repositories carry two variants of the licence, and the difference is
deliberate. The dataset bundle is under the **WRDS-Conditioned** variant
(v1.0): your rights are conditioned on holding your own current Compustat/WRDS
licence — an acceptance click, not a capability, since every user of those
artifacts already holds one; without it there is no panel to score against. The
model repository — and with it the regularization statistics — is under the
**plain** variant (v1.0): no firm-level value can be reconstructed from the
weights or the aggregate statistics, so downloading them requires no WRDS
entitlement. Both variants are non-commercial only, no redistribution,
attribution required, with all commercial rights reserved to The University of
Texas at Austin.

The licence texts are **not** reproduced in this repository — that would put
non-commercial grants inside an Apache-2.0 tree, which is the exact confusion
the split exists to prevent. Each ships as `LICENSE.md` in its gated repository
and is what the gate presents for acceptance; the `LICENSE` file here is
Apache-2.0 and governs the code alone.

Both gates are **automatic** — any Hugging Face account can accept the terms
and get immediate access. Authenticate once with `huggingface-cli login` (or
set `HF_TOKEN`), then:

```bash
pip install -e .[data]
```

> **Coarseness is not the test.** Six aggregate moments over a 600,000-row
> column reveal nothing firm-level — but they are still *derived* from a
> non-commercially-licensed source, and derivation is what the WRDS terms
> attach to. Gating the regularization statistics while shipping the column
> statistics as "just aggregates" would be an inconsistency, so both are gated.

Earlier releases did distribute the regularization statistics, the bitmap and
the row index under Apache-2.0. Those copies remain public and that grant is
irrevocable; this describes what is distributed **going forward**.

### What is credential-free

`validate` and `evaluate` against `examples/` touch none of this — no WRDS
login, no Hugging Face token, no network:

```bash
proforma20q validate examples/example_forecast.parquet
proforma20q evaluate examples/example_forecast.parquet --truth examples/example_truth.parquet
```

---

## Data & artifacts

**No firm-level WRDS-derived *values* are distributed** — you rebuild the
tabular/tuple artifacts yourself from your own Compustat licence
(`proforma20q build`). The released bundle (~21.6 GB total) is served from the
[gated dataset repository](https://huggingface.co/datasets/forma-lab-mccombs/proforma-20q-artifacts),
which is the sole source for every file below. Fetch and verify them with:

```bash
python scripts/download_artifacts.py --out data/artifacts
python scripts/download_artifacts.py --only full_sample_grid_rows.parquet   # or a subset
```

Every file is md5-checked against the pins below before it is accepted: a
download lands under `<name>.unverified` and is renamed to the real filename
only once it verifies, so a truncated or substituted file fails loudly instead
of scoring silently against the wrong bytes — and the rejected bytes are left
behind under that name for inspection. Exhibit labels refer to the paper's
Table 1 (Panel A = squared-error track, Panel B = absolute-error track):

| artifact | size | md5 | for |
|---|---|---|---|
| `forma_fgrid__pf_full__test__predictions.parquet` | 3.7 GB | `1820fcc9…` | canonical R13 **Forma** 5-seed Gaussian mixture (squared-error track). Pool your model against it to reproduce the **Panel A** Full column, or rebuild the mask from it. |
| `ffnn_linear_b50__pf_full__test__predictions.parquet` | 4.4 GB | `e419c833…` | **FFNN (linear)** 5-seed mixture — Panel A comparator row. |
| `ffnn_large_b50__pf_full__test__predictions.parquet` | 4.5 GB | `915779a3…` | **FFNN (large)** 5-seed mixture — Panel A comparator row. |
| `forma_lap05_fgrid__pf_full__test__predictions.parquet` | 7.4 GB | `1e8b0415…` | canonical R13 **Forma** Laplace mixture (absolute-error track) — the **Panel B** Full column. |
| `forma_lap05_fgrid__pf_full__test__predictions.nll.json` | 33 B | `a3d8659a…` | the Laplace file's **family sidecar**. Keep it next to the parquet (the evaluator reads `{stem}.nll.json`); without it the file is **silently scored as Gaussian**. |
| `full_sample_mask_bits.npy` | 66 MB | `a36008d8…` | the 327,244,429-cell Full-sample mask (grid-aligned packbits, no firm ids); pass to `evaluate --sample-mask`. |
| `full_sample_grid_rows.parquet` | 1.9 MB | `adbc2ae6…` | the canonical **row index** (`grid_row, firm, origin`) the mask is a bitmap over — 352,962 rows. Pass as `evaluate --grid-rows` to apply the mask to a vintage-drifted rebuild; see [the mask section](#reproduce-the-papers-pooled-columns). It carries gvkeys, hence the gate. |
| `coverage_by_horizon.csv` | 3.4 KB | `a0949f70…` | the **per-horizon calibration series** behind the paper's coverage claim — horizons 1–20 plus a pooled row, with `mean_pit`, `z2_mixture`, `crps_mixture` and central-interval coverage at nominal 50/80/90/95% for the canonical Forma 5-seed Gaussian mixture. |

The mask and its row index **used to ship in this repository** under
`artifacts/`. They are Compustat-derived, so they now come from the gated
dataset repository with everything else — download them once and pass the paths
to `evaluate`:

```bash
python scripts/download_artifacts.py --only full_sample_mask_bits.npy full_sample_grid_rows.parquet
```

> **Joining these files to your own build:** `origin`/`quarter` in the forecasts
> is a quarter-*end* timestamp at **microsecond** precision, while a canonical
> `tabular_test` stores nanoseconds — `…23:59:59.999999` vs `…23:59:59.999999999`,
> which are **not equal** as raw timestamps. `proforma20q` is immune (it
> canonicalizes every origin to a calendar quarter), but a hand-written
> `pd.merge` on the raw column silently returns nothing. Compare on
> `pd.to_datetime(s).dt.to_period("Q")`. `full_sample_grid_rows.parquet` sidesteps
> this by storing `origin` as a plain ISO date.

They hold only **model outputs — no firm-level values**. This release covers
the **point track (Panels A and B)**; the density track (Panel C — exact
mixture NLL/CRPS) needs the five per-seed forecasts and is out of scope here
([#3](https://github.com/forma-lab-mccombs/proforma-20q/issues/3) tracks it).

### Calibration series

`coverage_by_horizon.csv` is the per-horizon series the paper points at when it
reports pooled central-interval coverage of **72.6 / 89.6 / 93.7 / 95.8%** at
nominal 50/80/90/95% — the claim that Forma's intervals never under-cover at
any horizon. The file carries all 20 horizons plus the pooled row, so that
statement can be checked horizon by horizon rather than taken on the pooled
summary alone. Every model publishes its series under its own
`calibration/<model>_calibration/` directory in the dataset repository — this
one is `forma_fgrid`. The comparators (`chronos_raw`, `ffnn_large_b50`,
`ffnn_linear_b50`, `forma_lap05_fgrid`) sit beside it there; they are not in
the download manifest, since the paper's coverage credential is the canonical
Gaussian mixture.

### Documentation

| artifact | what it is |
|---|---|
| [`docs/release_documentation.pdf`](docs/release_documentation.pdf) | Detailed technical documentation in three parts: **A** the data pipeline (sample formation, splits, regularization, the 78-item universe, availability, and the accounting identities), **B** model training/implementation detail and every competitor's exact specification, **C** the LLM benchmark protocol with the prompts reproduced in full. |
| [`docs/prompts/`](docs/prompts/) | The byte-exact system prompts for both elicitation arms, with published SHA-256 anchors ([`docs/README.md`](docs/README.md)). Part C's typeset copies are ASCII transliterations; these files are the originals. |

> **This repository holds the canonical `release_documentation.pdf`**
> (`sha256 347c32111942ef2d2819347152008460d1ddf9fc56bd2234e1cfe4ddf6a56e0c`).
> A byte-identical copy also ships in the companion model repository, so that
> anyone holding only that repository still has Parts B and C, which describe
> its code. If the two digests ever differ, this copy wins — regenerate both
> together.

### Dollar-space forecasts, and the truth panel they merge against

The benchmark scores in the regularized (asinh z-score) target space. A separate
release,
[`forma-lab-mccombs/forma-usd-forecasts`](https://huggingface.co/datasets/forma-lab-mccombs/forma-usd-forecasts)
(gated dataset), carries the same Forma forecasts back-transformed to **millions
of USD** — for readers who want to use them without reimplementing the
normalization chain. It ships predictive quantiles rather than a standard
deviation: the inverse transform is `sinh`, which is asymptotically exponential,
so a Gaussian in z-space has a heavy right tail in dollars and a mirrored one
into negative dollars — a standard deviation would be dominated by the top few
percent of cells.

It cannot ship the realized values, which are verbatim Compustat. Rebuild them
from your own pull:

```bash
python scripts/build_usd_truth.py --compustat your_fundq.parquet --out data/usd_truth.parquet
```

**Do not merge raw Compustat columns against those forecasts.** 26 of the 78
targets either do not exist under those names or do not mean the same thing
under them: 20 are quarterly flows de-cumulated from a fiscal-YTD item, and 6
are computed. `wcapq` is the one that bites — Compustat ships a column by that
name, it merges cleanly, and the benchmark defines it as `actq - lctq`. The
script imports `convert_ytd_to_quarterly`, `add_computed_features` and the
target universe from `proforma20q` rather than restating them, so it resolves
targets through the same code path as `proforma20q build`. A computed target is
emitted only if it was actually recomputed — never by falling back to a
like-named native column.

**Pull with the canonical filters.** `comp.fundq` carries several format
variants per firm-quarter; the universe is `indfmt=INDL, datafmt=STD, consol=C,
popsrc=D` ([`task.yaml`](src/proforma20q/configs/task.yaml), `universe.compustat_filters`).
Include those four columns and the script applies the filters itself. Without
them it cannot, and warns: de-duplication would otherwise keep whichever variant
your query happened to return last.

| step | output rows | wall | peak RSS |
|---|---|---|---|
| 200 k firm-quarters, ~53 % of cells populated | 8.3 M | 2.3 s | 1.4 GB |
| 800 k firm-quarters, ~53 % populated | 33.4 M | 10.0 s | 5.2 GB |
| 800 k firm-quarters, all 78 targets populated | 62.4 M | 15.3 s | 9.0 GB |

Cost scales with **output** rows at roughly **0.13–0.15 GB per million**,
dominated by the assembled long frame and its `object`-dtype sort rather than by
any intermediate. Density is what decides where in that range you land: the
canonical ~1.7 M firm-quarter panel is **~10 GB at the sparsity Compustat
actually has, and ~18 GB if every target were populated**. Restrict with
`--targets` if that is tight. (Not to be confused with a *full-coverage
forecast*, which this README defines elsewhere as 550,620,720 rows — a different
quantity.)

---

## Task definition = single source of truth

Everything that defines the benchmark is in
[`src/proforma20q/configs/task.yaml`](src/proforma20q/configs/task.yaml)
(splits, targets, horizons, transform hyperparameters, size proxy, industry FE),
with the 78-item universe in `feature_sets.yaml` and the FF48 SIC ranges in
`ff48_sic_ranges.json`. Changing any of these defines a *different* benchmark and
invalidates published checksums and leaderboard numbers.

## Probabilistic track status

The point-forecast metrics (R²/MAE/MSE) and the single-family NLL/CRPS/calibration
metrics are final. Mixture NLL, PIT histograms, and Diebold–Mariano tests are
being finalized in the main research repo and will be ported here to match the
paper's evaluation to the digit — tracked, not forked.

## License

Code is licensed **Apache-2.0** (see [LICENSE](LICENSE) / [NOTICE](NOTICE)). **No
firm-level data is distributed** (see [Data & artifacts](#data--artifacts)); you
are responsible for your WRDS/Compustat/CRSP license.
The FF48 industry classification derives from the Kenneth R. French Data Library.

If you use ProForma-20Q, please cite it — see [CITATION.cff](CITATION.cff).
