import numpy as np
from epsforecast.synthetic import make_compustat
from epsforecast.features import build_predictors, fit_winsor_bounds, apply_winsor, PREDICTORS


def _panel():
    return build_predictors(make_compustat(n_firms=60, n_quarters=40, seed=1))


def test_lags_have_no_lookahead():
    # epsfxq_lag1 at row t must equal epsfxq at t-1 within the same firm
    df = _panel().sort_values(["gvkey", "datadate"])
    g = df.groupby("gvkey")
    expected = g["epsfxq"].shift(1)
    # compare only where both defined
    m = df["epsfxq_lag1"].notna() & expected.notna()
    assert np.allclose(df.loc[m, "epsfxq_lag1"], expected[m])


def test_winsor_bounds_come_from_training_only():
    df = _panel()
    train = df[df["datadate"] < "2008-01-01"]
    bounds = fit_winsor_bounds(train, PREDICTORS + ["epsfxq"])
    # an extreme value injected ONLY in the test period must not move the bounds
    df2 = df.copy()
    test_idx = df2.index[df2["datadate"] >= "2008-01-01"][0]
    df2.loc[test_idx, "epsfxq_lag1"] = 1e9
    train2 = df2[df2["datadate"] < "2008-01-01"]
    bounds2 = fit_winsor_bounds(train2, PREDICTORS + ["epsfxq"])
    assert bounds["epsfxq_lag1"]["hi"] == bounds2["epsfxq_lag1"]["hi"]


def test_apply_winsor_clips_to_bounds():
    df = _panel()
    bounds = fit_winsor_bounds(df, ["epsfxq_lag1"])
    out = apply_winsor(df, bounds)
    assert out["epsfxq_lag1"].max() <= bounds["epsfxq_lag1"]["hi"] + 1e-9
    assert out["epsfxq_lag1"].min() >= bounds["epsfxq_lag1"]["lo"] - 1e-9


def test_lags_require_fiscal_contiguity():
    # a firm with a missing fiscal quarter must get NaN lags across the gap,
    # not silently misaligned values grabbed from the wrong quarter
    base = make_compustat(n_firms=1, n_quarters=10, seed=3).sort_values("datadate")
    base = base.reset_index(drop=True)
    gapped = base.drop(index=3).reset_index(drop=True)  # remove 2000 Q4
    out = build_predictors(gapped)

    # 2001Q1 sits right after the hole: its previous fiscal quarter is missing -> lag1 NaN
    row_after_gap = out[(out["fyearq"] == 2001) & (out["fqtr"] == 1)].iloc[0]
    assert np.isnan(row_after_gap["epsfxq_lag1"])

    # 2001Q4 is 4 positions but 5 fiscal quarters after 2000Q3 -> lag4 NaN
    row_l4 = out[(out["fyearq"] == 2001) & (out["fqtr"] == 4)].iloc[0]
    assert np.isnan(row_l4["epsfxq_lag4"])

    # away from the hole the lags survive: 2000Q3 lag1 equals 2000Q2 EPS,
    # and 2002Q1 lag4 (a clean 4-quarter span over the hole's far side) equals 2001Q1 EPS
    row_ok = out[(out["fyearq"] == 2000) & (out["fqtr"] == 3)].iloc[0]
    q2_2000 = base[(base["fyearq"] == 2000) & (base["fqtr"] == 2)].iloc[0]
    assert row_ok["epsfxq_lag1"] == q2_2000["epsfxq"]
    row_2002q1 = out[(out["fyearq"] == 2002) & (out["fqtr"] == 1)].iloc[0]
    q1_2001 = base[(base["fyearq"] == 2001) & (base["fqtr"] == 1)].iloc[0]
    assert row_2002q1["epsfxq_lag4"] == q1_2001["epsfxq"]
