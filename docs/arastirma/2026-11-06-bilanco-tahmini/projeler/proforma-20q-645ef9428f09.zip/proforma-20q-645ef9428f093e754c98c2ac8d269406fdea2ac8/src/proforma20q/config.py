"""Loaders for the bundled, version-controlled task configuration.

Everything the benchmark needs to *define* itself ships inside the package (see
``configs/``): the canonical task parameters, the pf_full feature set, and the
FF48 SIC ranges. None of that is WRDS-derived.

The canonical regularization statistics are a different matter. They are
Compustat-derived and are fetched from a gated Hugging Face repository rather
than bundled here -- see :mod:`proforma20q.gated`.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

CONFIG_DIR = Path(__file__).resolve().parent / "configs"
REFERENCE_DIR = Path(__file__).resolve().parent / "reference"

# The published canonical dataset tag. `--tag` names an OUTPUT dataset and is
# free-form; this is the tag the published regularization statistics belong to.
CANONICAL_TAG = "r13_node_optionD_indfe_val8"

# The canonical regularization statistics, gated. Published alongside the model
# weights so the (mu, sigma, k) defining the target space have a single source
# of truth shared with the trained models. The digest is over the published
# file, which is content-identical to the copy this package shipped through
# v0.1 (same 15,000 (feature, quarter) rows, zero difference in mu/sigma/k) but
# written by a different parquet writer, hence a different md5.
REG_STATS_REMOTE = "reference/regularization_stats.parquet"
REG_STATS_MD5 = "a4cec0d8254b04cb57e7f543a901fa62"


def canonical_reg_stats_path(tag: str = CANONICAL_TAG) -> Path:
    """Where a *local* copy of the canonical ``regularization_stats`` would live.

    The file is no longer bundled (it is Compustat-derived; see NOTICE), so this
    path usually does not exist. It stays supported as an override: drop a copy
    here, or pass ``--reg-stats <path>``, and no network access is needed.
    Callers that just want a usable file should use
    :func:`ensure_canonical_reg_stats`.
    """
    fs = load_task_config()["benchmark"]["feature_set"]
    return REFERENCE_DIR / f"regularization_stats__{fs}__{tag}.parquet"


def ensure_canonical_reg_stats(tag: str = CANONICAL_TAG) -> Path:
    """Resolve the canonical ``regularization_stats``, downloading if required.

    Prefers a local copy (the override above, tag-specific first, then the
    canonical tag) and otherwise fetches the published file from the gated
    ``forma-lab-mccombs/forma`` repository and verifies its md5.

    Passing the result (or ``--reg-stats canonical``) to the build pins the
    target / eval normalization to the published R13 space, so the scored
    targets are independent of the builder's Compustat vintage and BLAS/LAPACK
    stack. Raises :class:`proforma20q.gated.GatedArtifactError` if the file is
    neither local nor reachable -- never silently re-estimates, because a
    re-estimated target space shares ~0% of its target cells with the published
    one.
    """
    for candidate_tag in dict.fromkeys((tag, CANONICAL_TAG)):
        local = canonical_reg_stats_path(candidate_tag)
        if local.exists():
            return local
    from .gated import FORMA_MODEL_REPO, fetch_verified
    return fetch_verified(FORMA_MODEL_REPO, REG_STATS_REMOTE, REG_STATS_MD5,
                          repo_type="model")


def canonical_id_map_path(name: str, tag: str = CANONICAL_TAG) -> Path:
    """Path to a pinned canonical id-map CSV (``account_id_map`` /
    ``industry_id_map``).

    These pin the tuple view's embedding orderings (see
    ``build.verify_id_maps``). There is deliberately no canonical
    ``firm_id_map`` here: the gvkey universe drifts with the Compustat vintage,
    so the firm map is checked by ordering rule and count instead.
    """
    fs = load_task_config()["benchmark"]["feature_set"]
    return REFERENCE_DIR / f"{name}__{fs}__{tag}.csv"


@lru_cache(maxsize=None)
def load_task_config() -> dict[str, Any]:
    """The canonical ProForma-20Q task definition (``configs/task.yaml``)."""
    with open(CONFIG_DIR / "task.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


@lru_cache(maxsize=None)
def load_feature_sets() -> dict[str, Any]:
    """The feature-set definitions (``configs/feature_sets.yaml``)."""
    with open(CONFIG_DIR / "feature_sets.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


@lru_cache(maxsize=None)
def load_ff48_ranges() -> dict[str, Any]:
    """The Fama-French 48 industry SIC ranges (``configs/ff48_sic_ranges.json``)."""
    with open(CONFIG_DIR / "ff48_sic_ranges.json", encoding="utf-8") as fh:
        return json.load(fh)


def _resolve_include_sets(name: str, sets: dict[str, Any], _seen: set[str]) -> list[str]:
    """Recursively expand a feature set's ``include_sets`` into a flat item list."""
    if name in _seen:
        return []
    _seen.add(name)
    spec = sets[name]
    items: list[str] = []
    for inc in spec.get("include_sets", []) or []:
        items.extend(_resolve_include_sets(inc, sets, _seen))
    for group in ("balance_sheet", "income_statement", "cash_flow", "computed"):
        items.extend(spec.get(group, []) or [])
    # Preserve first-seen order, drop duplicates.
    seen: set[str] = set()
    ordered: list[str] = []
    for it in items:
        if it not in seen:
            seen.add(it)
            ordered.append(it)
    return ordered


def feature_set_items(feature_set: str = "pf_full") -> list[str]:
    """The ordered list of statement items (targets) for a feature set.

    For ``pf_full`` this is the canonical 78-item universe the benchmark
    forecasts jointly.
    """
    sets = load_feature_sets()["feature_sets"]
    if feature_set not in sets:
        raise KeyError(
            f"Unknown feature set {feature_set!r}. Available: {sorted(sets)}")
    return _resolve_include_sets(feature_set, sets, set())


def pf_full_targets() -> list[str]:
    """The 78 pf_full statement items -- the benchmark's joint forecast targets."""
    return feature_set_items("pf_full")
