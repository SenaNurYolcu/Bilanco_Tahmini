# Quarterly EPS Forecasting

One-quarter-ahead forecasts of Compustat diluted EPS (`epsfxq`) from lagged, scaled
fundamentals, benchmarked out-of-sample against a seasonal-naive model and evaluated against
the raw reported target.

## Results

| Model | OOS RMSE | OOS MAE |
|---|---|---|
| Gradient-boosted trees | 5.1630 | 0.7530 |
| OLS (firm-clustered SEs) | 5.1678 | 0.7828 |
| Seasonal-naive (`epsfxq_{t-4}`) | 5.1879 | 0.8469 |

Against what firms actually reported, the three models are nearly tied on RMSE (GBM minus
0.48% vs the naive) because a few extreme reported EPS values dominate squared loss; the gap
is clearer on MAE (GBM minus 11.1%). The naive benchmark is the test `epsfxq_lag4` clipped at
the train 1/99 predictor bounds, the same regressor the models read, and that is the stronger
version: the raw unclipped lag scores RMSE 6.4942 and MAE 0.9227, so the comparison is
conservative. The edge is small but systematic: loss-differential tests for GBM vs naive give
t = 5.7 (squared loss) and t = 31.8 (absolute loss) clustered by firm, t = 3.3 and t = 15.0
clustered by quarter; for GBM vs OLS, t = 2.4 and t = 25.1 by firm, t = 4.1 and t = 20.0 by
quarter. Outlier-robust evaluation variants show larger relative RMSE gains (minus 21.2%
winsorizing the evaluation target at train 1/99 bounds, minus 5.9% at 0.1/99.9, minus 8.6%
excluding |EPS| > 10); they are reported in the notebook's
sensitivity table, not as the headline. Most of the edge is EPS persistence: a GBM on the two
EPS lags alone reaches RMSE 5.1678 against the full model's 5.1630, and the fundamentals add
almost no linear value (see [`REPORT.md`](REPORT.md) Section 6). The GBM beats the naive in 5
of 6 test years; 2024 is a near-tie in the naive's favor.

## Pipeline at a glance
1. Build EPS lags and scaled, lagged fundamentals (no look-ahead, lags validated against the
   fiscal calendar), see `src/epsforecast/features.py`.
2. Chronological train/test split; 1/99 winsorization bounds fit on train only, applied to the
   train predictors and target and to the test predictors; the test target stays raw for
   evaluation.
3. Fit OLS (firm-clustered SEs, interpretable) and a gradient-boosting challenger.
4. Score out-of-sample RMSE and MAE against the raw test target, with an outlier sensitivity
   table, firm- and quarter-clustered significance tests, and a by-year robustness check.

## What this does and does not show
* It shows a reproducible forecasting pipeline, leakage-controlled within the limits stated in
  the report (Compustat is as-restated, not point-in-time), that beats a seasonal-naive EPS
  benchmark out of sample by a small raw-target margin that clustered tests call systematic,
  with larger relative gains under outlier-robust evaluation.
* It does not cover financial firms: the leverage input requires `lctq`, which banks and
  insurers rarely report, so the estimation panel is de facto ex-financials (see
  [`REPORT.md`](REPORT.md) Section 3).
* It does not show that the full fundamental feature set is linearly essential; the OLS ablation
  says the opposite.
* It does not claim a production-grade earnings model. There is one chronological split, no
  industry or firm fixed effects, and no hyperparameter search.

## Two documents
* [`REPORT.md`](REPORT.md), the research report: why each decision was made, the OLS and GBM
  tradeoff, the per-variable economics, results interpreted statistically, assumptions, and
  limitations.
* [`notebooks/quarterly_eps_forecasting.ipynb`](notebooks/quarterly_eps_forecasting.ipynb)
  the technical notebook: the code (shown inline) and the executed outputs.

## Run it (no WRDS needed)
Requires Python 3.13; the pinned versions in `requirements.txt` match the environment the
results were produced in.
Public reproduction uses synthetic data by default when the licensed parquet file is absent.

```bash
pip install -r requirements.txt
pip install -e .
pytest -q                      # tests run on synthetic data
EPS_DATA_DIR=/tmp/eps-synthetic PYTHONPATH=$PWD/src \
  python -m jupyter nbconvert --to notebook --execute notebooks/quarterly_eps_forecasting.ipynb \
  --output /tmp/quarterly_eps_forecasting.executed.ipynb
jupyter notebook notebooks/quarterly_eps_forecasting.ipynb
```
With WRDS Compustat, drop `comp_data.parquet` into the `data/` directory at the repository root
(or set `EPS_DATA_DIR` to the directory that contains it). The loader resolves `data/` relative
to the repository root, not to the current working directory, so this works no matter where the
notebook is launched from. On load it prints exactly one provenance line, with file or
directory names only so committed outputs never embed local paths:
`[epsforecast] using REAL data from comp_data.parquet` when the file is found, or
`[epsforecast] WARNING: comp_data.parquet not found, generating SYNTHETIC data in <dir>` before
a schema-faithful synthetic panel is generated automatically.

## Data and licensing
Compustat via WRDS. The data is licensed and is NOT included or redistributed. Notebook outputs
are aggregate statistics and model results only, never raw rows.
The committed notebook/HTML were executed on the licensed research snapshot, but the displayed
outputs are aggregate diagnostics, model statistics, and plots only; no raw licensed rows are
redistributed.

## Provenance
Originated as a group class project (MGMT 557, Purdue, Spring 2026): Abigail Johnson, Dario
D'Isanto, Rahal Ranasinghe. Rebuilt, revised, and extended solo by Dario D'Isanto.
