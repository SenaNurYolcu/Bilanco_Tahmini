"""Out-of-sample evaluation: chronological split, RMSE, seasonal-naive benchmark."""
from __future__ import annotations
import numpy as np
import pandas as pd
import statsmodels.api as sm


def rmse(y_true, y_pred) -> float:
    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    m = ~np.isnan(y_true)
    if m.sum() == 0:
        return float("nan")
    return float(np.sqrt(np.mean((y_true[m] - y_pred[m]) ** 2)))


def mae(y_true, y_pred) -> float:
    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    m = ~np.isnan(y_true)
    if m.sum() == 0:
        return float("nan")
    return float(np.mean(np.abs(y_true[m] - y_pred[m])))


def time_split(df: pd.DataFrame, cutoff: str):
    cut = pd.Timestamp(cutoff)
    return df[df["datadate"] < cut].copy(), df[df["datadate"] >= cut].copy()


def seasonal_naive_rmse(df: pd.DataFrame) -> float:
    """Benchmark required by the rubric: predict epsfxq_t with epsfxq_{t-4}."""
    return rmse(df["epsfxq"].to_numpy(), df["epsfxq_lag4"].to_numpy())


def loss_differential_test(y_true, pred_a, pred_b, groups, loss: str = "squared"):
    """Panel Diebold-Mariano-style comparison of two forecasts with firm-clustered SEs.

    Per observation, d_i = loss(pred_b_i) - loss(pred_a_i), so a positive mean means model A
    has the systematically lower loss. The mean of d is the constant of an OLS of d on 1 with
    cluster-robust standard errors by `groups` (gvkey), the same clustering as models.fit_ols,
    so the t-statistic accounts for within-firm correlation of forecast errors.
    Returns (mean_differential, t_stat).
    """
    y = np.asarray(y_true, float)
    a = np.asarray(pred_a, float)
    b = np.asarray(pred_b, float)
    g = np.asarray(groups)
    m = ~(np.isnan(y) | np.isnan(a) | np.isnan(b))
    if loss == "squared":
        d = (y[m] - b[m]) ** 2 - (y[m] - a[m]) ** 2
    elif loss == "absolute":
        d = np.abs(y[m] - b[m]) - np.abs(y[m] - a[m])
    else:
        raise ValueError(f"unknown loss {loss!r}, use 'squared' or 'absolute'")
    res = sm.OLS(d, np.ones_like(d)).fit(cov_type="cluster", cov_kwds={"groups": g[m]})
    return float(res.params[0]), float(res.tvalues[0])


def oos_report(test, ols_model, gbm_model, predictors, *, y_true) -> pd.DataFrame:
    """RMSE on the held-out (later) quarters for OLS, GBM, and seasonal-naive.

    The target is passed explicitly as ``y_true`` so the caller decides what the metrics
    are computed against (the RAW test target for the headline numbers); nothing is read
    silently from a possibly-clipped ``epsfxq`` column of ``test``.
    """
    yt = np.asarray(y_true, float)
    rows = []
    rows.append({"model": "OLS", "rmse_oos": rmse(yt, ols_model.predict(test))})
    rows.append({"model": "GBM",
                 "rmse_oos": rmse(yt, gbm_model.predict(test[predictors].to_numpy()))})
    rows.append({"model": "seasonal_naive", "rmse_oos": rmse(yt, test["epsfxq_lag4"].to_numpy())})
    return pd.DataFrame(rows).sort_values("rmse_oos").reset_index(drop=True)
