# Research Report, Quarterly EPS Forecasting

*The reasoning behind the experiment: every design decision, the economic logic and include or
exclude tradeoff of each predictor, and the results interpreted statistically, including the
main limitations. The companion notebook (`notebooks/quarterly_eps_forecasting.ipynb`) is the
technical notebook (code, executed outputs, diagnostics); this document is the argument.*

---

## 1. Abstract

We forecast Compustat diluted quarterly EPS (`epsfxq`) one quarter ahead from lagged, scaled
fundamentals, and ask one central question: does a structured model beat the trivial
seasonal-naive forecast out-of-sample, judged against the raw reported target? On a strict
chronological hold-out (train strictly before 2020-05-31, 227,444 firm-quarters; test starts at
the cutoff, datadate 2020-05-31 onward, 51,020; the cutoff is the 80th percentile of this
snapshot's unique quarter-end dates, computed and printed by the split cell), the answer is
yes, narrowly on RMSE and more clearly on MAE; the cutoff is a fiscal-quarter-end date, not an
announcement date, so reporting vintage blurs slightly at the boundary. Against the raw test target the gradient-boosted model
reaches RMSE 5.1630 versus 5.1678 for OLS and 5.1879 for the seasonal naive (minus 0.48% versus
the naive), and MAE 0.7530 versus 0.8469 for the naive (minus 11.1%); the published naive clips
the test lag at train bounds, the stronger and therefore conservative version of the benchmark
(Section 6). The raw RMSE gap is small because a few extreme reported EPS values dominate
squared loss, but it is systematic: gvkey-clustered loss-differential tests give t = 5.74
(squared loss) and t = 31.76 (absolute loss) for GBM versus naive, and t = 2.40 and t = 25.14
for GBM versus OLS; clustered by quarter instead, the four t-statistics are 3.31, 15.02, 4.15,
and 20.01, so the ranking survives both clustering axes. Outlier-robust evaluation variants
show larger relative RMSE gains (minus 21.2% winsorizing the evaluation
target at train 1/99 bounds, minus 5.9% at 0.1/99.9, minus 8.6% excluding |EPS| > 10); these
are reported as sensitivity, never as the headline. Main qualification: most of the improvement
is EPS persistence. A GBM on the two EPS lags alone reaches RMSE 5.1678 against the full
model's 5.1630, and the fundamentals add almost nothing linearly (OLS lags only 5.1684, OLS
full 5.1678). The model wins, but for a narrow, disclosed reason.

## 2. Motivation and question

Quarterly EPS is heavily watched; reliable improvement over a naive forecast is valuable. EPS
forecasting also creates material look-ahead risk. The project therefore tests a modest claim, not a
grand fundamental-model claim: can lagged EPS plus lagged accounting ratios beat a seasonal-naive
forecast out of sample?

* H1: lagged EPS and lagged fundamentals carry information beyond the seasonal EPS lag.
* Constraint: every input is dated at least one fiscal quarter before the predicted quarter,
  and the model is judged only on data unseen in fitting. Because the snapshot is as-restated
  Compustat rather than point-in-time data, "dated before" is not the same as "known before";
  the residual gap is stated in the Limitations.

Benchmark to beat: the strong, standard seasonal-naive forecast, `epsfxq_t` approximated by
`epsfxq_{t-4}`. Exact published definition: the test `epsfxq_lag4` clipped at the train-window
1/99 predictor bounds, the same regressor matrix the models read. Section 6 shows this is the
stronger of the two natural definitions, so the published comparison is the conservative one.

## 3. Data

Source and provenance. Compustat Fundamentals Quarterly via WRDS (table `comp.fundq`), saved
once as a local parquet snapshot (`data/comp_data.parquet`) and read by the committed loader
(`src/epsforecast/data.py`). The original WRDS extraction query was not preserved, so the
dataset is defined operationally: it is whatever the committed loader selects from the
committed snapshot. The notebook's load section documents the sample from the data itself
rather than from memory: 423,909 firm-quarter rows, 12,145 unique firms (`gvkey`), `datadate`
from 2000-01-31 to 2025-06-30. The snapshot is as-downloaded on a single date and is not
refreshed, it reflects Compustat values as restated at download time.

Columns used: firm and period identifiers (`gvkey`, `datadate`) and the fiscal calendar
(`fyearq`, `fqtr`); the target `epsfxq` (diluted EPS excluding extraordinary items); the
raw items the predictors are built from (`ibq`, `oancfq`, `atq`, `lctq`, `ltq`, `saleq`,
`cogsq`); and `sic`, used only to characterize the sample, never as a predictor. The data is
licensed and not redistributed, only aggregates and results are shown; a schema-faithful
synthetic generator runs the pipeline without WRDS.

Sample selection (disclosed, and decomposed in the notebook). The complete-case step keeps
278,464 of 423,909 rows (65.7%) and drops 145,445. The binding constraint is missing
fundamentals, not lag construction: 94,594 of the dropped rows (65.0%) already have the target
and both EPS lags and die on a missing accounting input. The dominant one is leverage: among
those rows, 69,727 are missing `lev_lag1`, 91.6% of them financial firms (SIC 6000-6999), and
a missing leverage value traces to missing `lctq` in 99.9% of missing-`lev` firm-quarters,
banks and insurers simply do not report a current-liabilities split. The sector consequence is
large: SIC 6000-6999 accounts for 50.4% of dropped rows but only 3.5% of kept rows, so the
estimation panel is de facto ex-financials. The lag warm-up and the fiscal-contiguity guard on
the EPS lags (2,028 rows, Section 4.1) are secondary. In effect this is a quality filter with a
sector bite, not a neutral mechanical step, and the results should be read as evidence about
non-financial firms.

## 4. Pipeline and design decisions (the why)

**4.1 Why everything is lagged.** Each predictor is shifted at least one quarter within firm;
the seasonal term is EPS lagged 4 quarters. Every input is dated at least one fiscal quarter
before the target quarter, the core structural defense against look-ahead, enforced by unit
tests. The lag is by fiscal quarter, not by announcement date: the snapshot is as-restated
Compustat, so a lagged value is the current Compustat figure for that quarter, not necessarily
the figure that was public at the time (see Limitations). Lags are also validated against the
fiscal calendar (`fyearq`, `fqtr`): a lag of n quarters is kept only when the firm's
fiscal-quarter index gap is exactly n, so a firm that skips a quarter gets a missing lag (the
row then drops in the complete-case step) instead of a silently misaligned one; this guard
nulls 2,028 EPS-lag rows.

**4.2 Why scaled ratios.** Raw items scale with firm size; we divide by assets or sales so the
cross-section is comparable and the linear model cannot just learn "big firm, big number."

**4.3 Why winsorize, what is winsorized, and what is not.** Accounting data has heavy tails and
outright errors (raw `epsfxq` reaches into the tens of thousands in absolute value). For
fitting we winsorize, keep every row and pull the extreme tails to a data-driven bound, rather
than drop outliers (loses real firms, biases the sample) or hard-cap at arbitrary fixed values;
the 1st/99th percentile is the empirical-finance standard. Bounds are fit on the training
window only, fitting on the full sample would leak future tails into the past. They are applied
to the train predictors and the train target (a fitting choice, train side only) and to the
test predictors only; the test target is never clipped, out-of-sample metrics are computed
against what firms actually reported. That choice matters: 4,080 raw test targets (8.00% of the
test window) lie outside the train 1/99 target bounds, the 2020 to 2025 window is fatter-tailed
than the training years, so evaluating against a clipped target would rewrite 8% of the
outcomes. The headline is therefore raw, and the clipped views are demoted to a sensitivity
table. The notebook's two histograms (raw versus winsorized at 1/99) show the transformation
applied on the fitting side.

**4.4 Why RMSE and MAE (not MAPE).** EPS routinely crosses zero, so percentage errors (MAPE)
explode and are meaningless near zero. RMSE is in EPS dollars, the same units as the
seasonal-naive benchmark, so comparisons are direct, and on the raw target it genuinely
penalizes large misses; the sensitivity table quantifies how much, the raw RMSE level (about
5.2) collapses to 0.67 to 0.85 once the evaluation target is winsorized at 1/99, so the squared
loss is dominated by a thin extreme tail. We therefore report MAE alongside RMSE: it is far
less tail-sensitive and separates the models more visibly (GBM minus 11.1% versus the naive on
MAE, minus 0.48% on RMSE).

**4.5 Why OLS and GBM.** OLS is the interpretable baseline (readable coefficients,
firm-clustered standard errors because EPS is autocorrelated within a firm). GBM is the
non-linear challenger that captures interactions OLS cannot, at the cost of interpretability and
higher overfit risk. Its hyperparameters (`max_depth=3`, `learning_rate=0.05`, `max_iter=400`,
`l2_regularization=1.0`) are fixed hand-chosen values, not the sklearn defaults: no search was
performed, and the test split was never evaluated against during development, though with a
single split a residual selection effect cannot be fully excluded. Trees are scale-invariant,
so the scaled ratios matter for OLS, not the GBM.

## 5. Predictors, economic logic, expected sign, and include or exclude tradeoff

All are lagged and (except the EPS lags) scaled. Main qualification: the ablation (below) shows
these fundamentals add little linear value beyond the two EPS lags. We keep them because they
are economically motivated and standard, the GBM extracts a measurable non-linear sliver from
them (the lags-only GBM ablation in the notebook's Section 6a computes it: dropping the
fundamentals raises the GBM's raw-target RMSE from 5.1630 to 5.1678), and the VIFs (all below
2.7) show they do not destabilize the model. The evidence on the fundamentals is block-level (the joint ablations and
the coefficient table); no per-variable ablation is computed, so the table below does not rank
individual contributions. A reader who wants a parsimonious linear model could justifiably drop
most of them; we disclose that.

| Predictor | Definition | Economic logic | Exp. sign | Include or exclude tradeoff |
|---|---|---|---|---|
| `epsfxq_lag1` | EPS, prior quarter | Short-run earnings persistence | positive | Essential, strongest single anchor, near-zero cost. Keep. |
| `epsfxq_lag4` | EPS, same quarter last year | Seasonality (for example retail Q4) | positive | Essential, the benchmark itself; correlation 0.52 with lag1 but VIF 1.4. Keep. |
| `cfo_lag1` | `oancfq/atq` | Cash-based profitability; high-CFO earnings are higher quality and more persistent | positive | Economically strong; correlation minus 0.65 with accruals (by construction) but VIF 2.4. Keep. |
| `accruals_lag1` | `ROA minus CFO` (Sloan) | High accruals mean-revert, lower future earnings (earnings quality) | negative | Negative and significant in the printed coefficient table (Sloan-consistent); its individual contribution is not separated out, the fundamentals are ablated only as a block. Keep, with that caveat disclosed. |
| `gross_margin_lag1` | `(saleq - cogsq)/saleq` | Pricing power persists | positive | Simple, interpretable, significant in the printed table; assessed only jointly with the other fundamentals. Keep. |
| `asset_turnover_lag1` | `saleq/atq` | DuPont asset efficiency | positive | Complements margin in the DuPont view; significant in the printed table, assessed only at the block level. Keep. |
| `sales_growth_lag1` | `saleq/saleq_{t-4} minus 1` | Top-line momentum to bottom line via operating leverage | positive | Significant in the printed table; any value beyond the EPS lags is measured only at the block level (Section 6 ablations), not per variable. Keep. |
| `lev_lag1` | `(ltq - lctq)/atq` | Long-term leverage, interest-expense drag on net income | negative | Significant in the printed table, with the sign flip discussed in Section 6; no per-variable ablation is computed. Kept for completeness of the capital-structure view. |

The expected signs above are priors, not results. In the fitted model two of them flip:
leverage enters positive and CFO negative. Section 6 reports the printed coefficients and
discusses why the partial, conditional-on-EPS-lags reading differs from the unconditional
prior.

Why ROA was dropped. By construction `accruals = ROA minus CFO`, so `ROA = CFO + accruals` is a
linear combination of two included predictors; including it too would be perfectly collinear (a
singular design) and contribute zero marginal information. We keep CFO and accruals (the
economically distinct components) and drop ROA.

## 6. Results, interpreted

Out-of-sample, against the raw test target (test = 2020-05-31 onward, 51,020 firm-quarters):

| Model | OOS RMSE | OOS MAE | RMSE vs naive | MAE vs naive |
|---|---|---|---|---|
| Gradient-boosted trees | 5.1630 | 0.7530 | minus 0.48% | minus 11.1% |
| OLS (firm-clustered SEs) | 5.1678 | 0.7828 | minus 0.39% | minus 7.6% |
| Seasonal-naive (`epsfxq_{t-4}`) | 5.1879 | 0.8469 | reference | reference |

Significance (notebook Section 6d). Per-observation loss differentials (naive or OLS loss
minus GBM loss, squared and absolute, raw target) are regressed on a constant with
gvkey-clustered and, separately, datadate-clustered standard errors, the panel analogue of a
Diebold-Mariano test and the formal significance statement for the ranking. All four mean
differentials are positive, GBM losses are systematically lower: GBM versus naive, mean 0.2575
with t = 5.74 firm-clustered and t = 3.31 quarter-clustered (squared) and mean 0.0939 with
t = 31.76 and t = 15.02 (absolute); GBM versus OLS, mean 0.0503 with t = 2.40 and t = 4.15
(squared) and mean 0.0298 with t = 25.14 and t = 20.01 (absolute). The ranking is significant
under both clustering axes; the squared-loss t-statistics are the smaller ones because the same
extreme quarters dominate every model's squared errors.

Sensitivity to extreme test-target values (RMSE shown here, MAE in the notebook). The raw row
is the claim, the rest measures how much the comparison depends on tail handling:

| Evaluation variant | % test rows clipped or excluded | GBM | OLS | naive | GBM vs naive |
|---|---|---|---|---|---|
| raw (headline) | 0.00 | 5.1630 | 5.1678 | 5.1879 | minus 0.48% |
| winsor 1/99, train bounds | 8.00 | 0.6692 | 0.6935 | 0.8493 | minus 21.2% |
| winsor 0.1/99.9, train bounds | 0.92 | 1.3724 | 1.3913 | 1.4592 | minus 5.9% |
| exclude \|epsfxq\| > 10 | 0.85 | 1.0967 | 1.1185 | 1.2001 | minus 8.6% |

The relative gains grow as the tail is tamed, so the structured models earn their edge on the
body of the distribution while no model predicts the extreme quarters; the 1/99 row clips a
full 8.00% of test rows, which is exactly why it is sensitivity, not the headline.

Naive benchmark definition (the notebook cell after the sensitivity table). The published
seasonal naive is the test `epsfxq_lag4` clipped at the train 1/99 predictor bounds, the same
regressor matrix the models read; clipping changes the forecast on 4,032 test rows (7.90%).
That choice strengthens the benchmark: the raw, unclipped lag scores RMSE 6.4942 and MAE 0.9227
against the published 5.1879 and 0.8469, so the headline comparison is made against the harder
of the two naives and the direction of the definitional choice is conservative.

Ablation, where the edge actually comes from (raw target):

| Model | OOS RMSE |
|---|---|
| seasonal-naive (lag4) | 5.1879 |
| OLS (lags only) | 5.1684 |
| OLS (full) | 5.1678 |
| GBM (lags only) | 5.1678 |
| GBM (full) | 5.1630 |

Interpretation. Of the total naive-to-GBM RMSE reduction (0.0249), adding `epsfxq_lag1`
linearly gives 0.0195 (5.1879 to 5.1684), so short-run EPS persistence does most of the work,
and a lags-only GBM already reaches 5.1678 (that it matches OLS (full) to four decimals is a
rounding coincidence, not a structural identity). The fundamentals add 0.0006 linearly (5.1684
to 5.1678) and 0.0048 through the GBM's non-linearities (5.1678 to 5.1630), so a parsimonious
model could defensibly keep only the EPS lags. H1 holds only in that qualified sense: the
signal is dominated by EPS persistence, while the fundamental ratios matter mainly through
interactions, and modestly. This is the single most important caveat for anyone reading the
OLS table.

Multicollinearity. VIFs are all below 2.7 (maximum: accruals 2.63, CFO 2.39); the only notable
pairwise correlations are CFO with accruals (minus 0.65, by construction) and lag1 with lag4
(0.52). So coefficients are reasonably stable, collinearity is mild and, in any case, does not
bias out-of-sample prediction.

Overfitting check. In-sample RMSE is computed against the winsorized train target (the target
the models actually fit), out-of-sample against the raw test target, so the level of the gap
mostly reflects the raw test tail, not memorization; the informative comparison is between the
two models' gaps. OLS goes 0.4886 in-sample to 5.1678 out-of-sample (gap 4.6792), the GBM
0.4608 to 5.1630 (gap 4.7021). The GBM's gap is only marginally larger than OLS's, so its OOS
edge is not primarily explained by overfitting; it generalizes.

Robustness by year. The GBM beats the published seasonal naive in 5 of 6 test years; the
exception is 2024, a near-tie the naive wins by 0.002 (7.612 versus 7.610) in the year whose
RMSE is most tail-inflated. One year is definition-dependent and we do not claim it: in 2020
the GBM (4.334) edges the published clipped naive (4.370) but loses clearly to the raw,
unclipped naive (3.362), so the 2020 result flips with the benchmark definition. Consistent
otherwise, with one near-tie and one definitional caveat. The by-year sweep is supporting evidence, not the sole basis for the comparison: the
clustered loss-differential tests above are the formal significance statement for the model
ranking.

Coefficient signs (OLS). The EPS lags are positive (`epsfxq_lag1` 0.407, z = 48.6;
`epsfxq_lag4` 0.398, z = 46.8) and accruals is negative (minus 0.308, z = minus 10.7),
Sloan-consistent, as expected. Two estimated signs flip relative to the Section 5 priors.
`lev_lag1` enters positive (coefficient 0.063, z = 10.2), not negative: conditional on the EPS
lags, leverage plausibly correlates with the scale and earnings stability that let firms carry
long-term debt, rather than acting as a pure interest-expense drag, and we do not read the
partial coefficient causally. `cfo_lag1` enters negative (coefficient minus 0.298, z = minus
10.5), not positive: this is a partial effect conditional on the EPS lags and on accruals (CFO
and accruals are correlated at minus 0.65 by construction), so it measures how CFO covaries
with next-quarter EPS after persistence is already absorbed by the lags, not that cash flow
predicts lower earnings unconditionally. All eight coefficients are statistically significant
at p < 0.001 with firm-clustered standard errors; in a panel this large significance is easy to obtain,
and the ablation still shows the fundamentals' linear marginal contribution is small.

## 7. Assumptions

* Linearity (OLS), explicitly relaxed by the GBM, which is the measure of how much that
  assumption costs: 0.0048 RMSE on the raw target (5.1678 to 5.1630), 0.0243 under the 1/99
  winsorized evaluation (0.6935 to 0.6692).
* Pooled cross-section, one set of coefficients for all firms and industries.
* Stationarity, the predictor to EPS map is stable enough for pre-2020 parameters to transfer to
  2020 through 2025 (supported by the by-year view, 5 of 6 years against the published naive,
  with one near-tie and a definition-dependent 2020).
* Winsorization at 1/99 on the training side adequately handles data errors without distorting
  the signal; what the untouched raw test tail then does to the metrics is quantified in the
  sensitivity table rather than assumed away.

## 8. Limitations

* Most of the edge is EPS persistence, especially `epsfxq_lag1` plus `epsfxq_lag4`; the
  fundamentals justify themselves mainly through the GBM's non-linearity, and modestly.
* The raw-target RMSE ranking rests on a small margin (minus 0.48% versus the naive); the
  clustered tests call it systematic, but no model is usefully accurate in the extreme tail,
  where 8.00% of test targets fall outside the train 1/99 bounds.
* Single chronological split, no walk-forward re-estimation (mitigated by the by-year view).
* GBM hyperparameters fixed at hand-chosen values, no search performed (Section 4.5), its edge
  is un-optimized.
* Pooled, no industry or firm fixed effects; squared loss is dominated by extreme per-share
  EPS observations, as the sensitivity table quantifies; weaker for IPOs and restructurings.
* Financial firms (SIC 6000-6999) are effectively excluded by the missing-`lctq` leverage
  input: 3.5% of the kept panel versus 50.4% of dropped rows (Section 3). Nothing here is
  evidence about banks or insurers, and generalization to financials is untested.
* Sample selection additionally tilts toward firms with at least four quarters of contiguous
  history (Section 3).
* Not point-in-time. Compustat quarterly is as-restated, so predictors may embed revisions that
  were unknown when the quarter was originally reported; announcement dates (`rdq`, present in
  the snapshot but unused) are not used to lag availability, and late filers and restatements
  are residual leak vectors. Acceptable for a methodological showcase; the fix path is
  rdq-based availability lags or point-in-time snapshots.

## 9. Reproducibility

`pip install -r requirements.txt && pip install -e . && pytest -q` (synthetic data). Open the
notebook; with WRDS, place `comp_data.parquet` in `data/` or set `EPS_DATA_DIR`. The executed
notebook carries the real-data outputs.

## 10. Provenance and references

Group class project (MGMT 557, Purdue, Spring 2026): Abigail Johnson, Dario D'Isanto, Rahal
Ranasinghe; rebuilt, revised, and extended solo by Dario D'Isanto. Concepts: Piotroski
F-score, the Sloan (1996) accruals anomaly, the DuPont and Altman decompositions.
